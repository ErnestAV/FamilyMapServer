package request;

/**
 * Class for an EVENT REQUEST
 */
public class EventRequest {
    /** No request body */
}
