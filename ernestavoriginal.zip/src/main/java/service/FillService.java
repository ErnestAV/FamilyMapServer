package service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dao.*;
import data_generators.DataGeneration;
import data_generators.DataGenerator;
import model.Person;
import model.User;
import request.FillRequest;
import result.FillResult;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Random;

/**
 * A class for the Fill Service
 */
public class FillService {
    Database db;
    private UserDao uDao;
    private PersonDao pDao;
    private EventDao eDao;

    /**
    private ArrayList<String> maleNames;
    private ArrayList<String> femaleNames;
    private ArrayList<String> surNames;

    private ArrayList<String> locations;**/

    /**
     * @param username          - Username
     * @param numbOfGenerations - Generations
     * @return - A fill result
     */
    public FillResult fill(String username, int numbOfGenerations) throws DataAccessException {
        db = new Database();
        db.openConnection();
        Connection conn = db.getConnection();

        uDao = new UserDao(conn);
        pDao = new PersonDao(conn);
        eDao = new EventDao(conn);

        if (numbOfGenerations <= 0) {
            db.closeConnection(false);
            return new FillResult("Error: Number of generations has to be greater than 0", false);
        }
        try {
            User currentUser = uDao.find(username);
            if (currentUser == null) {
                db.closeConnection(false);
                return new FillResult("Error: User doesn't exist", false);
            }
            Person currentPerson = pDao.find(currentUser.getPersonID());
            if (!pDao.deletePersonsFromUser(currentUser.getUsername()) || !eDao.deleteEventsFromUser(currentUser.getUsername())){
                db.closeConnection(false);
                return new FillResult("Error while deleting Person and Event data for User", false);
            }
            else {
                DataGenerator dataGenerator = new DataGenerator();

                //Convert user to a person

                if (currentPerson == null) {
                    currentPerson = new Person();
                    currentPerson.setAssociatedUsername(currentUser.getUsername());
                    currentPerson.setFirstName(currentUser.getFirstName());
                    currentPerson.setLastName(currentUser.getLastName());
                    currentPerson.setGender(currentUser.getGender());
                }

                DataGeneration generationData = dataGenerator.generateAllTheGenerations(currentPerson, numbOfGenerations);

                for (int i = 0; i < generationData.getPersons().size(); i++) {
                    pDao.insert(generationData.getPersons().get(i));
                }

                for (int j = 0; j < generationData.getEventsArray().size(); j++) {
                    eDao.insert(generationData.getEventsArray().get(j));
                }

                db.closeConnection(true);
                return new FillResult("Successfully added " + generationData.getPersons().size()
                        + " persons and " + generationData.getEventsArray().size() + " events to the database.", true);
            }

        } catch (DataAccessException e) {
            e.printStackTrace();
            db.closeConnection(false);
        }
        db.closeConnection(false);
        return new FillResult("Error in Fill Service");
    }
/**
    private void getAllNames() {
        String[] paths = {"json/mnames.json", "json/fnames.json", "json/snames.json"};

        ArrayList<ArrayList<String>> allNames = new ArrayList<>();

        allNames.add(maleNames);
        allNames.add(femaleNames);
        allNames.add(surNames);

        for (int i = 0; i < paths.length; i++) {

            JsonObject jsonObject = JsonParser.parseString(paths[i]).getAsJsonObject();
            JsonArray jsonArray = jsonObject.get("data").getAsJsonArray();

            for (JsonElement name : jsonArray) {
                allNames.get(i).add(name.getAsString());
            }
        }
    }
    //Generate List (done)
    //Create event (For each person)
    //Create people
    //Check username (valid boolean)
    //Clear Data

    private void eventCreation() {

    }
/**
    private Person peopleCreation(int numGeneration, String gender) {
        Person mother = new Person();
        Person father = new Person();

        //If gen > 0
            // mother == createPeople (gene - 1, f)
            // father == createPeople (gen - 1, m)
            //setSpouseIDs to each other

            //try
                //db connection
                //create personDAO and eventDao
                //insert mother and father to the database
                //increment a person counter
                //createEvent marriage (use function written)

        //if (numGeneration == numbOfGenerations -- look at the top)
            //create user Person
        //else if (gender == female)
            //create mother
        //else
            //create father

        //for(i < eventTypes.size())
            //createEvent for the person generated

        //return person;
    }**/
}