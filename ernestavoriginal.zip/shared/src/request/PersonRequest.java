package request;

/**
 * A request class for PersonRequest
 */
public class PersonRequest {
    /** No request body */
}
