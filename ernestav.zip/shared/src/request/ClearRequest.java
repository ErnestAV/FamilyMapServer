package request;

/**
 * A class for a Clear Request
 */
public class ClearRequest {
    /** No request body */
}
